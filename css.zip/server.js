const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const bookings = {}; // Simple memory store

io.on('connection', socket => {
    console.log('Client connected');

    socket.on('panditLocation', data => {
        io.emit('panditLocationUpdate', data); // Broadcast to customer
    });

    socket.on('verifyPin', data => {
        // Real me DB check
        if (data.pin === '4589') { // Demo PIN
            io.emit('pinVerified');
        }
    });
});

server.listen(3000, () => console.log('Server running on port 3000'));